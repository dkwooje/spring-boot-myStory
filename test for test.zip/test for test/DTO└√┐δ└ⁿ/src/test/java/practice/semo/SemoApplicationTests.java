package practice.semo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
