package practice.semo.comment;


import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequiredArgsConstructor
public class CommentController {

    private final CommentRepository commentRepository;
    private final CommentService commentService;

    @GetMapping("/post/comment/{post_id}")
    String commentWrite1(@PathVariable Long post_id) {
        return "commentWrite.html";
    }
    @PostMapping("/post/comment/{post_id}")
    String commentWrite2(@PathVariable Long post_id, @RequestParam String content) {
        commentService.commentWrite(post_id, content);
        return "postMain.html";
    }


}
