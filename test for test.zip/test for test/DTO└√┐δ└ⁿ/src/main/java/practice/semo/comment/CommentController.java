package practice.semo.comment;


import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Optional;

@Controller
@RequiredArgsConstructor
public class CommentController {

    private final CommentRepository commentRepository;
    private final CommentService commentService;

    @GetMapping("/post/comment/{post_id}")
    String commentWrite1(@PathVariable Long post_id) {
        return "commentWrite.html";
    }
    @PostMapping("/post/comment/{post_id}")
    String commentWrite2(@PathVariable Long post_id, @RequestParam String content) {
        commentService.commentWrite(post_id, content);
        return "postMain.html";
    }

    @GetMapping("/post/comment/{post_id}/list")
    public String commentList(Model model, @PathVariable Long post_id) {
        List<CommentTable> comments = commentRepository.findByPost_Id(post_id);
        model.addAttribute("data", comments);
        return "commentList.html";
    }



    /*

    @PostMapping("/search")
    String postSearch(@RequestParam String searchText) {
        var result = itemRepository.findAllByTitleContains(searchText);
        // var result = itemRepository.rawQuery1(searchText);
        System.out.println(result);
        return "list.html";
    }
*/
}
